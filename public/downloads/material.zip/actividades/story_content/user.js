function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6NuFDXwoP2N":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

